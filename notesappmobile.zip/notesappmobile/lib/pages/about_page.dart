
import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
 Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Identitas Diri'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage('images/bisa.jpg'),
              ),
              SizedBox(height: 20),
              Text(
                'Siti Sarah Annashriyah ',
                style: TextStyle(fontSize: 20),
              ),
              Text(
                '2106046',
                style: TextStyle(fontSize: 20),
              ),
              Text(
                'Mahasiswa',
                style: TextStyle(fontSize: 20),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
