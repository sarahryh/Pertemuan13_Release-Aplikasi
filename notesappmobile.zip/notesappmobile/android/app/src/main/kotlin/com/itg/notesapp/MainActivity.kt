package com.itg.notesapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
